SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Consent](
	[ConsentID] [int] IDENTITY(1,1) NOT NULL,
	[ConsentDisplayName] [nvarchar](200) NOT NULL,
	[ConsentName] [nvarchar](200) NOT NULL,
	[ConsentContent] [nvarchar](max) NOT NULL,
	[ConsentGuid] [uniqueidentifier] NOT NULL,
	[ConsentLastModified] [datetime2](7) NOT NULL,
	[ConsentHash] [nvarchar](100) NOT NULL,
 CONSTRAINT [PK_CMS_Consent] PRIMARY KEY CLUSTERED 
(
	[ConsentID] ASC
)
)
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentDisplayName]  DEFAULT (N'') FOR [ConsentDisplayName]
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentName]  DEFAULT (N'') FOR [ConsentName]
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentContent]  DEFAULT (N'') FOR [ConsentContent]
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ConsentGuid]
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [ConsentLastModified]
GO
ALTER TABLE [dbo].[CMS_Consent] ADD  CONSTRAINT [DEFAULT_CMS_Consent_ConsentHash]  DEFAULT (N'') FOR [ConsentHash]
GO
