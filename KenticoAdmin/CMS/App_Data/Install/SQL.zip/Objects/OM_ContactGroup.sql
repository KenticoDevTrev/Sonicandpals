SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ContactGroup](
	[ContactGroupID] [int] IDENTITY(1,1) NOT NULL,
	[ContactGroupName] [nvarchar](200) NOT NULL,
	[ContactGroupDisplayName] [nvarchar](200) NOT NULL,
	[ContactGroupDescription] [nvarchar](max) NULL,
	[ContactGroupDynamicCondition] [nvarchar](max) NULL,
	[ContactGroupEnabled] [bit] NULL,
	[ContactGroupLastModified] [datetime2](7) NULL,
	[ContactGroupGUID] [uniqueidentifier] NULL,
	[ContactGroupStatus] [int] NULL,
 CONSTRAINT [PK_CMS_ContactGroup] PRIMARY KEY CLUSTERED 
(
	[ContactGroupID] ASC
)
)
GO
ALTER TABLE [dbo].[OM_ContactGroup] ADD  CONSTRAINT [DEFAULT_OM_ContactGroup_ContactGroupName]  DEFAULT (N'') FOR [ContactGroupName]
GO
