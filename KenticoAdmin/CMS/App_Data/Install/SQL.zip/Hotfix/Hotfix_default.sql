/* Temp_FormDefinition table serves for (alt)form definition modifications and is removed by HotfixProcedure */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Temp_FormDefinition'))
BEGIN
    CREATE TABLE [Temp_FormDefinition]
	(
		[TempID] [int] NOT NULL IDENTITY (1, 1),
		[ObjectName] [nvarchar] (200) NOT NULL,
		[FormDefinition] [nvarchar] (max) NULL,
		[IsAltForm] [bit] NULL,
		CONSTRAINT [PK_Temp_FormDefinition] PRIMARY KEY CLUSTERED ([TempID])
	) ON [PRIMARY];
END
ELSE
BEGIN
	DELETE FROM [Temp_FormDefinition];
END

GO

DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 4
BEGIN

INSERT INTO [Temp_FormDefinition] ([ObjectName], [FormDefinition], [IsAltForm])
VALUES ('media.library',
        '<form version="2"><field column="LibraryID" columntype="integer" guid="00fdb6b0-5f2e-4ef9-8648-1d3c7af8b721" isPK="true" system="true"><properties><fieldcaption>LibraryID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="LibraryDisplayName" columnsize="250" columntype="text" guid="9b4aa82c-02df-4712-a5b9-3b9dee377b45" system="true" translatefield="true" visible="true"><properties><fieldcaption>{$general.displayname$}</fieldcaption><fielddescription>{$medialibrary.librarydisplayname.description$}</fielddescription></properties><settings><controlname>localizabletextbox</controlname><ValueIsContent>False</ValueIsContent></settings></field><field column="LibraryName" columnsize="250" columntype="text" guid="e4081abf-652e-47bd-82d0-313752f01873" isunique="true" system="true" visible="true"><properties><fieldcaption>{$general.codename$}</fieldcaption><fielddescription>{$medialibrary.libraryname.description$}</fielddescription></properties><settings><controlname>codename</controlname></settings></field><field allowempty="true" column="LibraryDescription" columntype="longtext" guid="ac965989-ec7a-446f-81bb-ccb5043abf0b" system="true" translatefield="true" visible="true"><properties><fieldcaption>{$general.description$}</fieldcaption><fielddescription>{$medialibrary.librarydescription.description$}</fielddescription></properties><settings><controlname>LocalizableTextArea</controlname><ValueIsContent>False</ValueIsContent></settings></field><field allowempty="true" column="LibraryTeaserGUID" columntype="guid" guid="1cf86270-1d15-4a07-a3fb-4d97ba972c46" system="true" visible="true"><properties><fieldcaption>{$media.general.teaser$}</fieldcaption></properties><settings><controlname>metafileuploadercontrol</controlname><ObjectCategory>Thumbnail</ObjectCategory></settings></field><field column="LibraryFolder" columnsize="250" columntype="text" guid="06f6b6a9-08ca-4735-8732-20cc75d11802" system="true" visible="true"><properties><enabledmacro ismacro="true">{%FormMode == FormModeEnum.Insert|(user)administrator|(hash)0a89b968eb862d72bdc749e4095716028feb4b47d8cca3d195452ef627679385%}</enabledmacro><fieldcaption>{$general.foldername$}</fieldcaption><fielddescription>{$medialibrary.libraryfolder.description$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="LibraryAccess" columntype="integer" guid="720d2865-0be4-43d3-8ed8-412b269b1d00" system="true"><properties><fieldcaption>LibraryAccess</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field column="LibrarySiteID" columntype="integer" guid="99746a1e-3514-4c13-b878-7bb7b39ddb3d" system="true"><properties><defaultvalue ismacro="true">{%CurrentSite.SiteID|(user)administrator|(hash)f1f36b57555be68f4a774a617ef7f4b296d321c24bd971a578ae7443c86b1480%}</defaultvalue><fieldcaption>LibrarySiteID</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="LibraryGUID" columntype="guid" guid="512c11dd-a325-4bf2-b1be-4f7c54397132" system="true"><properties><fieldcaption>LibraryGUID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="LibraryLastModified" columntype="datetime" guid="54f9c352-5ac2-4e4b-ab98-65d41240e9e4" system="true"><properties><fieldcaption>LibraryLastModified</fieldcaption></properties><settings><controlname>calendarcontrol</controlname></settings></field><field allowempty="true" column="LibraryTeaserPath" columnsize="450" columntype="text" guid="5de9f8d9-3e2d-4d83-8a63-6c2bdfb76629" system="true"><properties><fieldcaption>LibraryTeaserPath</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="LibraryUseDirectPathForContent" columntype="boolean" guid="b84913d8-82f6-438e-abc2-f6e6c7e9e7b2" system="true" visible="true"><properties><fieldcaption>{$medialibrary.libraryusedirectpathforcontent.name$}</fieldcaption><fielddescription>{$medialibrary.libraryusedirectpathforcontent.description$}</fielddescription></properties><settings><controlname>CheckBoxControl</controlname></settings></field></form>',
        0);

END

IF @HOTFIXVERSION < 10
BEGIN

UPDATE [CMS_UIElement] SET
		[ElementVisibilityCondition] = '{%EditedObject.ClassHasURL || EditedObject.ClassIsCoupledClass|(identity)GlobalAdministrator|(hash)7510bbac5902b136c8ecfa300cba0e08e2c1b3457819de41eb44e239583bc13a%}'
	WHERE [ElementGUID]  = '39931a03-68ce-46fd-9ee3-1e019ff18826' 

END

IF @HOTFIXVERSION < 13
BEGIN

INSERT INTO [Temp_FormDefinition] ([ObjectName], [FormDefinition], [IsAltForm])
VALUES ('newsletter.emailtemplate.EditTemplateCode',
		'<form version="2"><field column="TemplateID" guid="1fc8d3e4-5b6f-4a8b-9266-42cfdd739d2d" /><field column="TemplateDisplayName" guid="d3505546-d312-4dda-aacc-cf1dfcb7bab3" visible="" /><field column="TemplateName" guid="d138a78c-5095-4778-a5a1-6c0e9d9c226e" visible="" /><field column="TemplateDescription" guid="96044a64-f381-440a-b613-673b845278a5" visible="" /><field column="TemplateInlineCSS" guid="8208c709-9f19-487e-b0a7-eb912316b1dd" visible="" /><field column="TemplateThumbnailGUID" guid="0f72ba1b-8b84-44a8-85a6-27107135071d" /><field column="TemplateIconClass" guid="b885071c-c113-44f1-8a94-d77a2f019cd9" /><field column="TemplateCode" guid="55b5079a-5163-4606-baeb-40e59c8f8aae" visible="true"><settings><AutoSize>False</AutoSize><controlname>MacroEditor</controlname><EnablePositionMember>False</EnablePositionMember><EnableSections>False</EnableSections><EnableViewState>False</EnableViewState><Height>600</Height><Language>7</Language><ResolverName ismacro="true">{% 
if (TemplateType == "I") /* using I as email Issue, this is defined in EmailTemplateTypeEnum */
  { "NewsletterResolver" }
else
  { "NewsletterConfirmationResolver" }
|(identity)GlobalAdministrator|(hash)7c7c10639461cfc02ce1352aaf617fc835cae60a9df72d7d6b97d8b2d220fe8b%}</ResolverName><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>True</ShowLineNumbers><SingleLineMode>False</SingleLineMode><SingleMacroMode>False</SingleMacroMode><SupportPasteImages>False</SupportPasteImages><Width>100%</Width></settings></field><field column="TemplateSiteID" guid="e8548e32-9ba1-4093-b00e-b6ab09d374e2" /><field column="TemplateType" guid="721c9b4a-60e2-4e9e-beef-8ca0e5612a89" visible="" /><field column="TemplateGUID" guid="4bf16188-eaa3-4b2a-bc44-897706226bae" /><field column="TemplateLastModified" guid="951b6ddb-4c52-4d94-a7dd-601f67b3658c" /><field column="TemplateSubject" guid="0eaddd8f-5a59-4873-afb1-80a7156918a6" /></form>',
		1);

END

/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '13' WHERE KeyName = N'CMSHotfixVersion'
GO
